import { Routes, Route, Navigate } from "react-router-dom";
import Sidebar from "./components/layout/Sidebar.jsx";
import Topbar from "./components/layout/Topbar.jsx";
import AdminDashboard from "./pages/admin/AdminDashboard.jsx";
import ViewEvents from "./pages/admin/ViewEvents.jsx";
import ManageUsers from "./pages/admin/ManageUsers.jsx";
import SystemSettings from "./pages/admin/SystemSettings.jsx";
import EventOverview from "./pages/admin/EventOverview.jsx";

export default function App() {
  return (
    <div className="min-h-screen">
      <Topbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          <Routes>
            <Route path="/" element={<Navigate to="/admin" replace />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/events" element={<ViewEvents />} />
            <Route path="/admin/events/:id" element={<EventOverview />} />
            <Route path="/admin/users" element={<ManageUsers />} />
            <Route path="/admin/settings" element={<SystemSettings />} />
            <Route path="*" element={<div>Not Found</div>} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
