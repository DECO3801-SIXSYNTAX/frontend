export const events = [
  { id: "tech-2024", name: "Tech Conference 2025", date: "2025-03-15", venue: "Convention Center", status: "Active", owner: "Planner Team A" },
  { id: "grad-2025", name: "Annual Graduation", date: "2025-04-22", venue: "University of Queensland", status: "Planning", owner: "Planner Team B" },
  { id: "gala-2025", name: "Wedding", date: "2025-05-08", venue: "Grand Ballroom", status: "Draft", owner: "Planner Team C" },
];

export const users = [
  { id: 1, name: "Teuku Auli", email: "auli@sipanit.app", role: "Planner", status: "Active", lastActive: "2m ago" },
  { id: 2, name: "Fiqo Anugrah", email: "fiqo@sipanit.app", role: "Vendor", status: "Active", lastActive: "1h ago" },
  { id: 3, name: "Ahmad Danindra", email: "danin@sipanit.app", role: "Planner", status: "Active", lastActive: "3h ago" },
  { id: 4, name: "Arya Chandra", email: "arya@sipanit.app", role: "Guest", status: "Suspended", lastActive: "1d ago" },
];
